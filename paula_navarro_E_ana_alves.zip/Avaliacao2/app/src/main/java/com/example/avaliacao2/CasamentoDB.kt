package com.example.avaliacao2

import android.content.Context
import android.widget.Toast
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Casamento::class], version = 1)
abstract class CasamentoDB: RoomDatabase() {

    abstract fun getCasamentoDAO() : CasamentoDAO

    companion object {

        private lateinit var INSTANCE : CasamentoDB

        fun getInstance(context: Context) : CasamentoDB {

            if (!::INSTANCE.isInitialized) {

                INSTANCE = Room.databaseBuilder(context, CasamentoDB::class.java, "casamento_db")
                    .allowMainThreadQueries()
                    .build()
            }
            return INSTANCE
        }


    }

}