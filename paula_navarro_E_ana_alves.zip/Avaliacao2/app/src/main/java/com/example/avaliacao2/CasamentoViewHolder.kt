package com.example.avaliacao2

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CasamentoViewHolder(casamentoLayout : View) : RecyclerView.ViewHolder(casamentoLayout) {

    var txtDadosCasamento = casamentoLayout.findViewById<TextView>(R.id.txtDadosCasamento)

}