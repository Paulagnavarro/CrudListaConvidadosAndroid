package com.example.avaliacao2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class CasamentoAdapter(var context: Context) : RecyclerView.Adapter<CasamentoViewHolder>() {

    private var casamentoDAO = CasamentoDB.getInstance(context).getCasamentoDAO()
    private var listaCasamentos = casamentoDAO.getCasamentos()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CasamentoViewHolder {
        var casamentoLayout = LayoutInflater.from(context)
            .inflate(R.layout.casamento_layout, parent, false)

        var casamentoViewHolder = CasamentoViewHolder(casamentoLayout)
        return casamentoViewHolder
    }

    override fun onBindViewHolder(holder: CasamentoViewHolder, position: Int) {
        var casamento = listaCasamentos.get(position)
        holder.txtDadosCasamento.text = casamento.toString()

        holder.txtDadosCasamento.setOnClickListener {
            var intent = Intent(context, CadastroActivity::class.java)

            intent.putExtra("id", casamento.id)

            context.startActivity(intent)
        }

        holder.txtDadosCasamento.setOnLongClickListener {
            casamentoDAO.deletarCasamento(casamento)
            atualizarAdapter()
            Toast.makeText(context, "Convidado excluído!", Toast.LENGTH_SHORT).show()
            true
        }

    }

    override fun getItemCount(): Int {
        return listaCasamentos.size
    }

    fun atualizarAdapter(){
        listaCasamentos = emptyList()
        listaCasamentos = casamentoDAO.getCasamentos()
        notifyDataSetChanged()
    }

    fun atualizarItemAdapter(position: Int){
        notifyItemRemoved(position)
        listaCasamentos.drop(position)
    }
}