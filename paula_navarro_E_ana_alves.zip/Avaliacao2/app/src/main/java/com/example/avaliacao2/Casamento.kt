package com.example.avaliacao2

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "casamentos")
data class Casamento (
    @PrimaryKey(autoGenerate = true) @ColumnInfo var id : Int,
    @ColumnInfo var nome : String,
    @ColumnInfo var email : String,
    @ColumnInfo var telefone : String
) {

    override fun toString(): String {
        return "Nome: ${nome} \n(Email: ${email} \n(Telefone: ${telefone})"
    }


}