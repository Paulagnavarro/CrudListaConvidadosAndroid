package com.example.avaliacao2

import androidx.room.*

@Dao
interface CasamentoDAO {

    @Insert
    fun salvarCasamento(casamento: Casamento) : Long

    @Delete
    fun deletarCasamento(casamento: Casamento)

    @Update
    fun atualizarCasamento(casamento: Casamento)

    @Query("SELECT * FROM casamentos WHERE id = :id")
    fun getCasamento(id: Int) : Casamento

    @Query("SELECT * FROM casamentos")
    fun getCasamentos(): List<Casamento>
}