package com.example.avaliacao2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.avaliacao2.databinding.ActivityCadastroBinding

class CadastroActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCadastroBinding
    private var dao = CasamentoDB.getInstance(this).getCasamentoDAO()
    private var id = 0;
    private lateinit var casamento: Casamento

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCadastroBinding.inflate(layoutInflater)

        setContentView(binding.root)

        id = intent.getIntExtra("id", 0);

        if (id > 0) {
            binding.txtAcaoActivity.text = "Editar Convidado"

            casamento = dao.getCasamento(id);

            binding.edtNome.setText(casamento.nome)
            binding.edtEmail.setText(casamento.email)
            binding.edtTelefone.setText(casamento.telefone)
        }

        binding.btnSalvar.setOnClickListener {
            validarDados()
        }

    }

    fun validarDados(){

        if (binding.edtNome.text.isEmpty() ||
            binding.edtEmail.text.isEmpty() ||
            binding.edtTelefone.text.isEmpty() ) {

            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT)
                .show()
            return

        } else {

            casamento = Casamento(
                id,
                binding.edtNome.text.toString(),
                binding.edtEmail.text.toString(),
                binding.edtTelefone.text.toString()
            )

            if (id > 0) {
                dao.atualizarCasamento(casamento)
                finish()
                return
            }

            if (dao.salvarCasamento(casamento) > 0) {
                Toast.makeText(this, "Convidado cadastrado!", Toast.LENGTH_SHORT)
                    .show()
                finish()
            } else {
                Toast.makeText(this, "Erro ao executar operação.", Toast.LENGTH_SHORT)
                    .show()
            }

        }

    }
}